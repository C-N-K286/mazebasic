﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movement : MonoBehaviour {
	private float moveh;
	private float constant;
	private float rotate;
	private float speed;
	private Rigidbody rb1;
	private Vector3 org;
	void Start () {
		moveh = transform.position.x;
		org = transform.position;
		constant = moveh;
		speed = 0.8f;
		rb1 = GetComponent<Rigidbody> (); 
	}
	void FixedUpdate () {
		moveh += speed;
		Vector3 move = new  Vector3 (moveh, 0, 0);
		rb1.AddForce (move);
		if(move.x > 11)
		{
			speed = -.08f;
		}
		if (move.x <= -5) {
			speed = 0.08f;
		}
	}

		}
