﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class balmovement : MonoBehaviour {
	private Rigidbody rb;
	private float speed =10;
	void Start () {
		rb = GetComponent<Rigidbody>();
	}
	void FixedUpdate () {
		float moveh = Input.GetAxis ("Horizontal");
		float movev = Input.GetAxis ("Vertical");
		Vector3 force = new Vector3 (moveh,0.02f,movev);
		rb.AddForce (force * speed);
	}
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag ("pick up")) {
			other.gameObject.SetActive (false);
		}
	}
}
